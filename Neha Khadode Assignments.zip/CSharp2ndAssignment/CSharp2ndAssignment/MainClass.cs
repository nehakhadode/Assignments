﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp2ndAssignment
{
    internal class MainClass
    {
        static void Main(String[] args)
        {
            Employee1 employee = new Employee1();
            Console.WriteLine("Enter the Employee ID: ");
            employee.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter your name: ");
            employee.EmpName = Console.ReadLine();
            Console.WriteLine("Please enter the salary for the Employee: ");
            employee.Salary = Convert.ToInt32(Console.ReadLine());
            employee.calculateSalary();
            Console.WriteLine("Gross Salary for Employee: " + employee.GrossSalary);
            Console.WriteLine("Net Salary for Employee: " + employee.NetSalary);

            Manager manager = new Manager();
            Console.WriteLine("Enter the Manager ID: ");
            manager.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name of manager: ");
            manager.EmpName = Console.ReadLine();
            Console.WriteLine("Enter the Salary for Employee: ");
            manager.Salary = Convert.ToDouble(Console.ReadLine());
            manager.calculateSalary();
            Console.WriteLine("Gross Salary for Manager: " + manager.GrossSalary);

            MarketingExecutive me = new MarketingExecutive();
            Console.WriteLine("Enter the ID for Marketing Executive: ");
            me.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name of Marketing Executive: ");
            me.EmpName = Console.ReadLine();
            Console.WriteLine("Enter the salary for Marketing Executive: ");
            me.Salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enters the kilometers by Marketing Executive: ");
            me.kilo = Convert.ToDouble(Console.ReadLine());
            me.calculateSalary();
            Console.WriteLine("Gross Salary of Marketing Executive: " + me.GrossSalary);
            Console.ReadKey();
        }
    }
}

CREATE TABLE Employee  
(  
EmployeeID int,  
EmployeeName nvarchar(255),   
Email nvarchar(255),   
AddressLine nvarchar(255),  
City nvarchar(255),
ManagerName nvarchar(50)
);

INSERT INTO Employee(EmployeeID,EmployeeName,Email,AddressLine,City,ManagerName)
VALUES(901,'Uzma','Uzma@gmail.com', 'M1','Hyderabad','Naveen'),
      (902,'Harsha','Harsha@gmail.com','M2','Suryapet','Aradhya'),
	  (903,'Chintoo','Chintoo@gmail.com','M3','vizag','Latha');

	  select * from Employee;

--1--
select * from customer 
where country='Germany';

--2--
select FirstName +' ' +LastName As FullName from Customer;

--3--
select * from customer
where FaxNumber IS NOT NULL;

--4--
select * from customer
where FirstName LIKE '_u%';

--5--
select * from Orderr
Left Outer join OrderItem
On Orderr.id=OrderItem.Orderid
where UnitPrice BETWEEN 48 AND 50;


--6--
select * from Orderr
where ShippingDate IS NOT NULL
ORDER BY OrderDate;

--7--
select id,OrderNumber
from Orderr
where ShipName='La corned' AND
OrderDate BETWEEN 1/1/2020 AND 31/12/2020;

--8--
select id,ProductName
from Products
where Supplier='Exotic Liquids';

--9--
select AVG(Quantity) as AvgQuantity
from Product
Right Outer join
OrderItem
On Product.id=OrderItem.Productid;

--10--
select EmployeeName,ManagerName 
from Employee;

--11--

--12--
select TotalPrice
from Orders
where Supplier='Exotic Liquids' AND TotalPrice > 50;








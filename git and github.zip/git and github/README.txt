You can define relative links and image paths in your rendered files to help readers navigate to other files in your repository.


 For example, if you have a README file in root of your repository, and you have another file in docs/CONTRIBUTING.md, the relative link to CONTRIBUTING.md in your README might look like this:

[Contribution guidelines for this project](docs/CONTRIBUTING.md)
GitHub will automatically transform your relative link or image path based on whatever branch you're currently on, so that the link or path always works. You can use all relative link operands, such as ./ and ../.

Relative links are easier for users who clone your repository. Absolute links may not work in clones of your repository - we recommend using relative links to refer to other files within your repository.
A paragraph is a series of related sentences developing a central idea, called the topic. Try to think about paragraphs in terms of thematic unity: a paragraph is a sentence or a group of sentences that supports one central, unified idea. Paragraphs add one idea at a time to your broader argument.

Most importantly, the holiday no matter how little it gives them a great chance to relax. More so because they work tirelessly for so many hours a day without a break. Some even work when they get home. This makes their schedule very hectic and gives them little time to rest. A holiday fills the gap for this rest.
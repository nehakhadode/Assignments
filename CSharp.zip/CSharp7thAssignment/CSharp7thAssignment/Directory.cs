﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CSharp7thAssignment
{
    class Directory
    {
        static void Main(string[] args)
        {
            String path = @"D:\MyTestFile2.txt";
            DirectoryInfo fl = new DirectoryInfo(path);
            fl.Create();
            {
                Console.WriteLine("Directory has been created");
            }
            Console.ReadLine();

        }
    }
}

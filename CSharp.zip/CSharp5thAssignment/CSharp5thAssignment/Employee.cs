﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp5thAssignment
{
    class Employee
    {


        public int EmpNo
        {
            get;
            set;
        }
        public string EmpName
        {
            get;
            set;
        }
        public double Salary
        {
            get;
            set;
        }
        public double HRA
        {
            get;
            set;
        }
        public double TA
        {
            get;
            set;
        }
        public double DA
        {
            get;
            set;
        }
        public double PF
        {
            get;
            set;
        }
        public double TDS
        {
            get;
            set;
        }
        public double NetSalary
        {
            get;
            set;
        }
        public double GrossSalary
        {
            get;
            set;
        }

        public override string ToString()
        {
            return "Emp No: " + EmpNo + "   Name: " + EmpName + "   Gross Salary: " + GrossSalary;
        }

        public double calculateHra()
        {
            if (Salary < 5000)
            {
                return .1 * Salary;
            }
            else if (Salary < 10000)
            {
                return .15 * Salary;
            }
            else if (Salary < 15000)
            {
                return .20 * Salary;
            }
            else if (Salary < 15000)
            {
                return .25 * Salary;
            }
            else
            {
                return .30 * Salary;
            }
        }
        public double calculateTa()
        {
            if (Salary < 5000)
            {
                return .05 * Salary;
            }
            else if (Salary < 10000)
            {
                return .1 * Salary;
            }
            else if (Salary < 15000)
            {
                return .15 * Salary;
            }
            else if (Salary < 15000)
            {
                return .20 * Salary;
            }
            else
            {
                return .25 * Salary;
            }
        }
        public double calculateDa()
        {
            if (Salary < 5000)
            {
                return .15 * Salary;
            }
            else if (Salary < 10000)
            {
                return .20 * Salary;
            }
            else if (Salary < 15000)
            {
                return .25 * Salary;
            }
            else if (Salary < 15000)
            {
                return .30 * Salary;
            }
            else
            {
                return .35 * Salary;
            }
        }

        public void calculateSalary()
        {
            this.HRA = calculateHra();
            this.TA = calculateTa();
            this.DA = calculateDa();

            this.GrossSalary = this.Salary + this.HRA + this.TA + this.DA;
            this.PF = .1 * this.GrossSalary;
            this.TDS = 0.18 * this.GrossSalary;
            this.NetSalary = this.GrossSalary - (this.PF + this.TDS);

        }


    }
    class EmployeeDetails
    {
        static void Main(string[] args)
        {
            string sSearch;
            List<Employee> employeeList = new List<Employee>();
            Console.WriteLine("Enter the details of First Employee: ");
            Employee employee1 = new Employee();
            Console.WriteLine("Id: ");
            employee1.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name: ");
            employee1.EmpName = Console.ReadLine();
            Console.WriteLine("Salary: ");
            employee1.Salary = Convert.ToDouble(Console.ReadLine());
            employee1.calculateSalary();


            Console.WriteLine("Enter the details of Second Employee: ");
            Employee employee2 = new Employee();
            Console.WriteLine("Id: ");
            employee2.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name: ");
            employee2.EmpName = Console.ReadLine();
            Console.WriteLine("Salary: ");
            employee2.Salary = Convert.ToDouble(Console.ReadLine());
            employee2.calculateSalary();

            Console.WriteLine("Enter the details of Third Employee: ");
            Employee employee3 = new Employee();
            Console.WriteLine("Id: ");
            employee3.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name: ");
            employee3.EmpName = Console.ReadLine();
            Console.WriteLine("Salary: ");
            employee3.Salary = Convert.ToDouble(Console.ReadLine());
            employee3.calculateSalary();

            Console.WriteLine("Enter the details of Fourth Employee: ");
            Employee employee4 = new Employee();
            Console.WriteLine("Id: ");
            employee4.EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name: ");
            employee4.EmpName = Console.ReadLine();
            Console.WriteLine("Salary: ");
            employee4.Salary = Convert.ToDouble(Console.ReadLine());
            employee4.calculateSalary();


            employeeList.Add(employee1);
            employeeList.Add(employee2);
            employeeList.Add(employee3);
            employeeList.Add(employee4);


            Console.WriteLine("Find the Employee Name: ");
            sSearch = Console.ReadLine();
            Employee oFind = employeeList.Find(e => e.EmpName.Equals(sSearch));
            if (oFind != null)
            {
                Console.WriteLine("Employee no: " + oFind.EmpNo + "Employee Salary: " + oFind.GrossSalary);
            }
            else
            {
                Console.WriteLine("Employee Not Found.");
            }

            Console.WriteLine();
            foreach (Employee employee in employeeList)
            {
                Console.WriteLine(employee);
            }
            Console.WriteLine("Total Number of Employees: " + employeeList.Count);
            Console.ReadKey();

        }
    }
}
